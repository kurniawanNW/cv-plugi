<!-- Vendors -->

<!-- Vendors -->

<script src="{{asset('resources/vendors/popper.js/popper.min.js')}}"></script>
<script src="{{asset('resources/vendors/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('resources/vendors/overlay-scrollbars/jquery.overlayScrollbars.min.js')}}"></script>

<!-- Vendors: Data tables -->
<script src="{{asset('resources/vendors/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('resources/vendors/datatables/datatables-buttons/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('resources/vendors/datatables/datatables-buttons/buttons.print.min.js')}}"></script>
<script src="{{asset('resources/vendors/jszip/jszip.min.js')}}"></script>
<script src="{{asset('resources/vendors/datatables/datatables-buttons/buttons.html5.min.js')}}"></script>

<!-- Site Functions & Actions -->
<script src="{{asset('resources/js/app.min.js"')}}></script>