 
<?php $__env->startSection('content'); ?>
 
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Server Process</h4>
                <h6 class="card-subtitle">Maecenas faucibus mollis interdum porttitor</h6>
    
                <div class="flot-chart flot-dynamic"></div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $('#sb-dashboard').addClass("active");
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\plugin-cv-master\resources\views/admin/beranda/beranda_index.blade.php ENDPATH**/ ?>