<aside class="sidebar navigation">
            <div class="scrollbar">
                <ul class="navigation__menu">
                    <li>
                        <a class="text-active-blue" href="/admin" id="sb-dashboard"><i
                                class="zwicon-home text-blue"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('tim')); ?>" class="text-active-red"  id="sb-tim"><i
                                class="zwicon-users"></i>TIM</a>
                    </li>
                    <li>
                    <a href="<?php echo e(route('Clients')); ?>" class="text-active-green" id="sb-clients"><i
                                class="zwicon-user-flow"></i>Klien</a>
                    </li>
                    <li>
                      <a href="<?php echo e(route('product')); ?>" class="text-active-green "><i
                              class="zwicon-layout-4 text-green"></i>Produk</a>
                  </li>
                </ul>
            </div>
        </aside><?php /**PATH C:\xampp\htdocs\plugin-cv-master\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>