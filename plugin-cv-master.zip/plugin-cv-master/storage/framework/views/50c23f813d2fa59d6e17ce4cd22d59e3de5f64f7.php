<!-- Vendors -->

<!-- Vendors -->

<script src="<?php echo e(asset('resources/vendors/popper.js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendors/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendors/overlay-scrollbars/jquery.overlayScrollbars.min.js')); ?>"></script>

<!-- Vendors: Data tables -->
<script src="<?php echo e(asset('resources/vendors/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendors/datatables/datatables-buttons/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendors/datatables/datatables-buttons/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendors/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('resources/vendors/datatables/datatables-buttons/buttons.html5.min.js')); ?>"></script>

<!-- Site Functions & Actions -->
<script src="<?php echo e(asset('resources/js/app.min.js"')); ?>></script><?php /**PATH C:\xampp\htdocs\plugin-cv-master\resources\views/layouts/script.blade.php ENDPATH**/ ?>