<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Material Admin Extended Dark</title>
<link rel="shortcut icon" href="favicon.png" type="image/png">

<!-- Vendor styles -->
<link rel="stylesheet" href="<?php echo e(asset('resources/vendors/zwicon/zwicon.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resources/vendors/animate.css/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resources/vendors/overlay-scrollbars/OverlayScrollbars.min.css')); ?>">

<!-- App styles -->
<link rel="stylesheet" href="<?php echo e(asset('resources/css/app.min.css')); ?>">

<script src="<?php echo e(asset('resources/vendors/jquery/jquery.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\plugin-cv-master\resources\views/layouts/head.blade.php ENDPATH**/ ?>