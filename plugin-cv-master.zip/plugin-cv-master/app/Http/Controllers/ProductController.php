<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;

class ProductController extends Controller
{
    public function index(){
        $products = Product::all();
        
        return view ('product.product_index', compact('products'));
    }
  
    public function store(Request $request){
        $this->validate($request, [
             'nama' => 'required',
             'deskripsi' => 'required',
             'gambar' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);
 
        $file = $request->file('foto');
  
         $nama_file = time()."_".$file->getClientOriginalName();
         
         $tujuan_upload = 'data_file';
         $file->move($tujuan_upload,$nama_file);
  
         Tim::create([
             'nama' => $request->nama,
             'deskripsi' => $request->deskripsi,
             'gambar' => $nama_file,
         ]);
  
         return redirect()->back();
    }
 
    public function hapus(Product $id){
         $id->delete();
 
         return redirect('/admin/product');
    }
}
