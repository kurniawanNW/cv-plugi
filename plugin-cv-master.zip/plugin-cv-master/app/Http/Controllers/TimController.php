<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Tim;

class TimController extends Controller
{
   public function index(){
       $tims = Tim::all();
       
       return view ('tim.tim_index', compact('tims'));
   }
 
   public function store(Request $request){
       $this->validate($request, [
            'nama' => 'required',
            'jabatan' => 'required',
            'foto' => 'required|image|mimes:jpeg,png,jpg|max:2048',
       ]);

       $file = $request->file('foto');
 
        $nama_file = time()."_".$file->getClientOriginalName();
        
        $tujuan_upload = 'data_file';
		$file->move($tujuan_upload,$nama_file);
 
		Tim::create([
            'nama' => $request->nama,
            'jabatan' => $request->jabatan,
			'foto' => $nama_file,
		]);
 
		return redirect()->back();
   }

   public function hapus(Tim $id){
        $id->delete();

        return redirect('/admin/tim');
   }
    
}
