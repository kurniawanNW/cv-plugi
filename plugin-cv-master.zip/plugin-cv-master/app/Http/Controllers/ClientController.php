<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Client;

class ClientController extends Controller
{
    public function index(){
        $Clients = Client::all();
        
        return view ('Clients.Clients_index', compact('Clients'));
    }
  
    public function store(Request $request){
        $this->validate($request, [
             'nama_perusahaan' => 'required',
             'logo' => 'required|image|mimes:jpeg,png,jpg|max:2048',
        ]);
 
        $file = $request->file('logo');
  
         $nama_file = time()."_".$file->getClientOriginalName();
         
         $tujuan_upload = 'data_file';
         $file->move($tujuan_upload,$nama_file);
  
         Client::create([
             'nama_perusahaan' => $request->nama_perusahaan,
             'logo' => $nama_file,
         ]);
  
         return redirect()->back();
    }
 
    public function hapus(Client $id){
         $id->delete();
 
         return redirect('/admin/Clients');
    }
}
